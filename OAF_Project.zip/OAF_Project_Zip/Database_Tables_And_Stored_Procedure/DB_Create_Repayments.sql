USE [OAFProject]
GO

/****** Object:  Table [dbo].[Repayments]    Script Date: 9/12/2019 7:38:01 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Repayments](
	[RepaymentID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[SeasonID] [int] NOT NULL,
	[RepaymentUploadID] [int] NOT NULL,
	[Date] [date] NULL,
	[Amount] [float] NOT NULL,
 CONSTRAINT [PK_Repayments] PRIMARY KEY CLUSTERED 
(
	[RepaymentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Repayments]  WITH CHECK ADD  CONSTRAINT [FK_Repayments_Customers] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])
GO

ALTER TABLE [dbo].[Repayments] CHECK CONSTRAINT [FK_Repayments_Customers]
GO

ALTER TABLE [dbo].[Repayments]  WITH CHECK ADD  CONSTRAINT [FK_Repayments_Seasons] FOREIGN KEY([SeasonID])
REFERENCES [dbo].[Seasons] ([SeasonID])
GO

ALTER TABLE [dbo].[Repayments] CHECK CONSTRAINT [FK_Repayments_Seasons]
GO

