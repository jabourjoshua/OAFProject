USE [OAFProject]
GO

/****** Object:  Table [dbo].[RepaymentUploads]    Script Date: 9/12/2019 7:37:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RepaymentUploads](
	[RepaymentUploadID] [int] IDENTITY(1,1) NOT NULL,
	[UploadTransferID] [int] NOT NULL,
	[CustomerID] [int] NULL,
	[SeasonID] [int] NULL,
	[Date] [date] NULL,
	[Amount] [float] NULL,
	[IsProcessed] [bit] NOT NULL,
 CONSTRAINT [PK_RepaymentUploads] PRIMARY KEY CLUSTERED 
(
	[RepaymentUploadID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[RepaymentUploads] ADD  CONSTRAINT [DF_RepaymentUploads_IsProcessed]  DEFAULT ((0)) FOR [IsProcessed]
GO

ALTER TABLE [dbo].[RepaymentUploads]  WITH CHECK ADD  CONSTRAINT [FK_RepaymentUploads_RepaymentUploadInstances] FOREIGN KEY([UploadTransferID])
REFERENCES [dbo].[RepaymentUploadTransfers] ([UploadTransferID])
GO

ALTER TABLE [dbo].[RepaymentUploads] CHECK CONSTRAINT [FK_RepaymentUploads_RepaymentUploadInstances]
GO


