USE [OAFProject]
GO

/****** Object:  Table [dbo].[CustomerSummaries]    Script Date: 9/12/2019 7:38:09 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerSummaries](
	[SummaryID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[SeasonID] [int] NOT NULL,
	[Credit] [float] NOT NULL,
	[TotalRepaid] [float] NOT NULL,
 CONSTRAINT [PK_CustomerSummaries] PRIMARY KEY CLUSTERED 
(
	[SummaryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CustomerSummaries]  WITH CHECK ADD  CONSTRAINT [FK_CustomerSummaries_Customers] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])
GO

ALTER TABLE [dbo].[CustomerSummaries] CHECK CONSTRAINT [FK_CustomerSummaries_Customers]
GO

ALTER TABLE [dbo].[CustomerSummaries]  WITH CHECK ADD  CONSTRAINT [FK_CustomerSummaries_Seasons] FOREIGN KEY([SeasonID])
REFERENCES [dbo].[Seasons] ([SeasonID])
GO

ALTER TABLE [dbo].[CustomerSummaries] CHECK CONSTRAINT [FK_CustomerSummaries_Seasons]
GO

