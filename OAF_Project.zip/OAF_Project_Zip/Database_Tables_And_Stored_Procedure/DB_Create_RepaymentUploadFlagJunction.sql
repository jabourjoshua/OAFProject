USE [OAFProject]
GO

/****** Object:  Table [dbo].[RepaymentUploadFlagJunction]    Script Date: 9/12/2019 7:37:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RepaymentUploadFlagJunction](
	[RepUpFlagJunctID] [int] IDENTITY(1,1) NOT NULL,
	[RepaymentUploadID] [int] NOT NULL,
	[UploadFlagID] [int] NOT NULL,
 CONSTRAINT [PK_RepaymentUploadFlagJunction] PRIMARY KEY CLUSTERED 
(
	[RepUpFlagJunctID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[RepaymentUploadFlagJunction]  WITH CHECK ADD  CONSTRAINT [FK_RepaymentUploadFlagJunction_RepaymentUploads] FOREIGN KEY([RepaymentUploadID])
REFERENCES [dbo].[RepaymentUploads] ([RepaymentUploadID])
GO

ALTER TABLE [dbo].[RepaymentUploadFlagJunction] CHECK CONSTRAINT [FK_RepaymentUploadFlagJunction_RepaymentUploads]
GO

ALTER TABLE [dbo].[RepaymentUploadFlagJunction]  WITH CHECK ADD  CONSTRAINT [FK_RepaymentUploadFlagJunction_UploadFlags] FOREIGN KEY([UploadFlagID])
REFERENCES [dbo].[UploadFlags] ([UploadFlagID])
GO

ALTER TABLE [dbo].[RepaymentUploadFlagJunction] CHECK CONSTRAINT [FK_RepaymentUploadFlagJunction_UploadFlags]
GO

