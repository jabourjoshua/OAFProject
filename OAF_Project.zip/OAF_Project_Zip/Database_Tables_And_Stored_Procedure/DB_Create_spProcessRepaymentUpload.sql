USE [OAFProject]
GO

/****** Object:  StoredProcedure [dbo].[spProcessRepaymentUpload]    Script Date: 9/12/2019 7:38:32 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- ====================================================================
-- Author: Joshua Jabour
-- Create date: September 11, 2019
-- Description: Process all payments from a specific uploaded file.
-- ====================================================================

CREATE   PROCEDURE [dbo].[spProcessRepaymentUpload] @uploadTransferID int
AS
BEGIN
	  SET NOCOUNT ON;
    -- declare variables
    DECLARE @RepaymentUploadID int;
    DECLARE @CustomerID int=null;
    DECLARE @SeasonID int;
    DECLARE @LatestSeasonID int;
    DECLARE @LatestSeasonSummaryID int;
    DECLARE @UnpaidSeasonID int;
    DECLARE @UnpaidSeasonSummaryID int;
    DECLARE @Date date;
    DECLARE @Amount float;
    DECLARE @NegativeOverpaymentAmount float;
    DECLARE @Credit float;
    DECLARE @TotalRepaid float;
    -- execute season/seasonless repayment entry logic
    -- iterate through uploaded repayment records
    While (Select Count(*) From dbo.RepaymentUploads Where IsProcessed = 0 and UploadTransferID = @uploadTransferID) > 0
    Begin
        Select Top 1 @RepaymentUploadID=RepaymentUploadID, @CustomerID=CustomerID, @SeasonID=SeasonID,
            @Date=Date, @Amount=Amount From dbo.RepaymentUploads Where IsProcessed = 0 and UploadTransferID = @uploadTransferID;
        IF @SeasonID is null -- seasonless entry
        BEGIN 
            -- get latest season (in case the latest season is paid but there is still an unpaid previous season)
            select top 1 @LatestSeasonID=cs.SeasonID, @LatestSeasonSummaryID=cs.SummaryID from dbo.Seasons s 
                inner join dbo.CustomerSummaries cs on s.SeasonID=cs.SeasonID
                where cs.CustomerID=@CustomerID
                order by s.StartDate desc;
            
            -- get unpaid seasons and credit/totalrepaid in chronological order and put them into a temp table then iterate through
            select s.SeasonID,cs.SummaryID,cs.Credit,cs.TotalRepaid into #ClientSeasons
                from dbo.Seasons s 
                inner join dbo.CustomerSummaries cs on s.SeasonID=cs.SeasonID
                where cs.CustomerID=@CustomerID
                and cs.Credit>cs.TotalRepaid
                order by s.StartDate asc;
            While (Select Count(*) From #ClientSeasons) > 0
            BEGIN
                Select Top 1 @UnpaidSeasonID=SeasonID,@UnpaidSeasonSummaryID = SummaryID,@Credit = Credit,@TotalRepaid = TotalRepaid From #ClientSeasons
                -- create positive payment to oldest unpaid season
                INSERT INTO dbo.Repayments(RepaymentUploadID,CustomerID,SeasonID,Date,Amount)
                    VALUES(@RepaymentUploadID,@CustomerID,@UnpaidSeasonID,@Date,@Amount);
                
                -- check to see if the whole amount should be applied to only this season
                -- (payment does not bring total over amount to be repaid or this is the latest season)
                IF @Credit>=@Amount+@TotalRepaid OR @UnpaidSeasonSummaryID=@LatestSeasonSummaryID
                BEGIN
                    -- update summary, and do not check any other seasons
                    update dbo.CustomerSummaries set TotalRepaid=TotalRepaid+@Amount
                        where SummaryID=@UnpaidSeasonSummaryID;
                    SET @Amount=0;
                    break;
                END
                ELSE
                BEGIN
                   -- update summary as fully repaid, create negative payment entry, and continue to next season
                   update dbo.CustomerSummaries set TotalRepaid=Credit
                        where SummaryID=@UnpaidSeasonSummaryID;
                   SET @NegativeOverpaymentAmount = @Credit-@TotalRepaid-@Amount;
                   INSERT INTO dbo.Repayments(RepaymentUploadID,CustomerID,SeasonID,Date,Amount)
                        VALUES(@RepaymentUploadID,@CustomerID,@UnpaidSeasonID,@Date,@NegativeOverpaymentAmount);
                   -- update @amount with remaining amount
                   SET @Amount=-@NegativeOverpaymentAmount;
                END
                -- delete record from temp table and move to next
                delete from #ClientSeasons Where SummaryID = @UnpaidSeasonSummaryID;
            END
            drop table if exists #ClientSeasons;
            -- Check for edge case where the latest season was already paid off, but not previous seasons.
            IF @Amount!=0
            BEGIN
                -- create positive payment to latest season and update summary
                INSERT INTO dbo.Repayments(RepaymentUploadID,CustomerID,SeasonID,Date,Amount)
                    VALUES(@RepaymentUploadID,@CustomerID,@LatestSeasonID,@Date,@Amount);
                update dbo.CustomerSummaries set TotalRepaid=TotalRepaid+@Amount
                    where SummaryID=@LatestSeasonSummaryID;
            END
        END
        ELSE -- season-specific entry
        BEGIN
            INSERT INTO dbo.Repayments(RepaymentUploadID,CustomerID,SeasonID,Date,Amount)
                VALUES(@RepaymentUploadID,@CustomerID,@SeasonID,@Date,@Amount);
            update dbo.CustomerSummaries set TotalRepaid=TotalRepaid+@Amount 
                where CustomerID=@CustomerID and SeasonID=@SeasonID;
        END
        -- mark this upload record as processed and move to the next
        Update dbo.RepaymentUploads Set IsProcessed = 1 Where RepaymentUploadID = @RepaymentUploadID;
    END
    -- mark upload transfer as processed and set timestamp
    update dbo.RepaymentUploadTransfers set IsProcessed=1,DateProcessed=getdate() where UploadTransferID = @uploadTransferID;
END
GO

