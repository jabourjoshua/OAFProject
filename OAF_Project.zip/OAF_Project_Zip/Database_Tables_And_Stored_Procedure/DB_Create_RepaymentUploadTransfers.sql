USE [OAFProject]
GO

/****** Object:  Table [dbo].[RepaymentUploadTransfers]    Script Date: 9/12/2019 7:37:17 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RepaymentUploadTransfers](
	[UploadTransferID] [int] IDENTITY(1,1) NOT NULL,
	[IsProcessed] [bit] NOT NULL,
	[DateTransferred] [datetime] NOT NULL,
	[DateProcessed] [datetime] NULL,
 CONSTRAINT [PK_RepaymentUploadInstances] PRIMARY KEY CLUSTERED 
(
	[UploadTransferID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[RepaymentUploadTransfers] ADD  CONSTRAINT [DF_RepaymentUploadTransfers_IsProcessed]  DEFAULT ((0)) FOR [IsProcessed]
GO

