﻿using OAFProject.Models;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;

namespace OAFProject.DAL
{
    public class OAFProjectDBContext : DbContext
    {
        public OAFProjectDBContext() : base("OAFProjectEntities")
        {

        }
        public DbSet<Season> Seasons { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<CustomerSummary> CustomerSummaries { get; set; }
        public DbSet<Repayment> Repayments { get; set; }
        public DbSet<RepaymentUpload> RepaymentUploads { get; set; }
        public DbSet<RepaymentUploadTransfer> RepaymentUploadTransfers { get; set; }
        public DbSet<UploadFlagSeverity> UploadFlagSeverities { get; set; }
        public DbSet<UploadFlag> UploadFlags  { get; set; }
        public DbSet<RepaymentUploadFlagJunction> RepaymentUploadFlagJunctions  { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            base.OnModelCreating(modelBuilder);
        }

        // Run stored procedure spProcessRepaymentUpload, passing in uploadTransferID
        public void spProcessRepaymentUpload(int uploadTransferID)
        {
            this.Database.ExecuteSqlCommand("exec spProcessRepaymentUpload @uploadTransferID",
                new SqlParameter("@uploadTransferID", uploadTransferID));
        }
    }
}