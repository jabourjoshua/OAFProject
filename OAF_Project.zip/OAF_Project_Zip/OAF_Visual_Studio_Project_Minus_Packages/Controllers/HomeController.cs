﻿using System.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Data;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using OAFProject.Models;
using OAFProject.DAL;

namespace OAFProject.Controllers
{
    public class HomeController : Controller
    {
        // Display all customer summaries in a table on a view
        public ActionResult ViewSummaries()
        {
            List<DisplaySummary> displaySummaries = new List<DisplaySummary>();
            using (OAFProjectDBContext context = new OAFProjectDBContext())
            {
                List<CustomerSummary> customerSummaries = context.CustomerSummaries
                    .OrderBy(x => x.CustomerID).ThenByDescending(x => x.SeasonID).ToList();
                foreach (CustomerSummary customerSummary in customerSummaries)
                {
                    // get data and store in a summary object list for displaying on the view
                    var seasonName = context.Seasons.Where(x => x.SeasonID == customerSummary.SeasonID).Select(x => x.SeasonName).FirstOrDefault();
                    var customerName = context.Customers.Where(x => x.CustomerID == customerSummary.CustomerID).Select(x => x.CustomerName).FirstOrDefault();
                    displaySummaries.Add(new DisplaySummary
                    {
                        CustomerID = customerSummary.CustomerID,
                        CustomerName = customerName,
                        SeasonID = customerSummary.SeasonID,
                        SeasonName = seasonName,
                        Credit = customerSummary.Credit,
                        TotalRepaid = customerSummary.TotalRepaid,
                        IsPaymentRequired = (customerSummary.Credit > customerSummary.TotalRepaid)
                    });
                }
            }
            return View(displaySummaries);
        }

        // Display all repayments in a table on a view
        public ActionResult ViewRepayments()
        {
            List<DisplayRepayment> displayRepayments = new List<DisplayRepayment>();
            using (OAFProjectDBContext context = new OAFProjectDBContext())
            {
                List<Repayment> repayments = context.Repayments
                    .OrderBy(x => x.Date).ThenBy(x => x.CustomerID)
                    .ThenByDescending(x => x.SeasonID).ToList();
                foreach (Repayment repayment in repayments)
                {
                    // get data and store in a repayment object list for displaying on the view
                    var seasonName = context.Seasons.Where(x => x.SeasonID == repayment.SeasonID).Select(x => x.SeasonName).FirstOrDefault();
                    var customerName = context.Customers.Where(x => x.CustomerID == repayment.CustomerID).Select(x => x.CustomerName).FirstOrDefault();
                    string date="";
                    if (repayment.Date.HasValue)
                    {
                        date = repayment.Date.Value.ToString("MM/dd/yyyy"); // apply approved date format
                    }
                    displayRepayments.Add(new DisplayRepayment
                    {
                        CustomerID = repayment.CustomerID,
                        CustomerName = customerName,
                        SeasonID = repayment.SeasonID,
                        SeasonName = seasonName,
                        Date = date,
                        Amount = repayment.Amount
                    });
                }
            }
            return View(displayRepayments);
        }

        // Upload a JSON repayments file
        public ActionResult UploadRepayments(string msg)
        {
            ViewBag.Message = msg; // pass any messages through to the view for alerts
            return View();
        }
        [HttpPost]
        public ActionResult UploadRepayments(HttpPostedFileBase RepaymentFile)
        {
            int uploadTransferID=0;
            if (RepaymentFile.ContentLength > 0)
            {
                try
                {
                    // get file contents to string
                    string str = (new StreamReader(RepaymentFile.InputStream)).ReadToEnd();

                    // deserialize string into list of repayments
                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    var repaymentUploads = serializer.Deserialize<List<RepaymentUpload>>(str);

                    // set season to null if season=0
                    foreach (RepaymentUpload repaymentUpload in repaymentUploads.Where(x => x.SeasonID==0))
                    {
                        repaymentUpload.SeasonID = null;
                    }

                    using (OAFProjectDBContext context = new OAFProjectDBContext()) {
                        // Add new transfer
                        if (ViewBag.Message == null)
                        {
                            var repaymentUploadTransfer = new RepaymentUploadTransfer
                            {
                                DateTransferred = DateTime.Now,
                                IsProcessed = false
                            };
                            context.RepaymentUploadTransfers.Add(repaymentUploadTransfer);

                            // Add associated repayments from the upload
                            context.RepaymentUploads.AddRange(repaymentUploads);
                            context.SaveChanges();
                            uploadTransferID = repaymentUploadTransfer.UploadTransferID;
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Add code to log error to logging system with details from exception as appropriate
                    ViewBag.Message = "File could not be uploaded. Please check the contents and try again.";
                }
                validateUploads(uploadTransferID);
            }
            else
            {
                ViewBag.Message = "File is empty or not found.";
            }
            if (ViewBag.Message == null) // if no upload errors then show review
            {
                return RedirectToAction("ReviewRepayments", "Home", new { uploadTransferID = uploadTransferID });
            }
            else // if there are upload errors then stay on the same page and display alert
            {
                return View();
            }
        }
        
        // Display a page for reviewing uploaded payments before they are processed.
        public ActionResult ReviewRepayments(int uploadTransferID)
        {
            ViewBag.UploadTransferID = uploadTransferID;
            List<DisplayUpload> displayUploads = new List<DisplayUpload>();
            using (OAFProjectDBContext context = new OAFProjectDBContext())
            {
                // get repayment uploads
                List<RepaymentUpload> repaymentUploads = context.RepaymentUploads.Where(x => x.UploadTransferID == uploadTransferID)
                    .OrderBy(x => x.CustomerID).ThenByDescending(x => x.SeasonID).ToList();
                var repaymentUploadIDs = repaymentUploads.Select(x => x.RepaymentUploadID).ToList();

                // get validation flags for all uploads with their descriptions and severities
                List<RepaymentUploadFlagJunction> repaymentUploadFlagJunctions = context.RepaymentUploadFlagJunctions.Where(x => repaymentUploadIDs.Contains(x.RepaymentUploadID)).ToList();
                List<UploadFlag> uploadFlags = context.UploadFlags.ToList();
                List<UploadFlagSeverity> uploadFlagSeverities = context.UploadFlagSeverities.ToList();
                List<UploadFlagsWithDescriptions> uploadFlagsWithDescriptions = new List<UploadFlagsWithDescriptions>();
                foreach (RepaymentUploadFlagJunction repaymentUploadFlagJunction in repaymentUploadFlagJunctions) {
                    var uploadFlag = uploadFlags.Where(x => x.UploadFlagID == repaymentUploadFlagJunction.UploadFlagID).FirstOrDefault();
                    var severity = uploadFlagSeverities.Where(x => x.FlagSeverityID==uploadFlag.FlagSeverityID).FirstOrDefault();
                    uploadFlagsWithDescriptions.Add(new UploadFlagsWithDescriptions
                    {
                        RepaymentUploadID = repaymentUploadFlagJunction.RepaymentUploadID,
                        FlagDescription = uploadFlag.Description,
                        SeverityDescription = severity.Description
                    });
                }

                // set data for repayments to display
                foreach (RepaymentUpload repaymentUpload in repaymentUploads)
                {
                    // get general data
                    var seasonName = context.Seasons.Where(x => x.SeasonID == repaymentUpload.SeasonID).Select(x => x.SeasonName).FirstOrDefault();
                    var customerName = context.Customers.Where(x => x.CustomerID == repaymentUpload.CustomerID).Select(x => x.CustomerName).FirstOrDefault();
                    string date=null;
                    if (repaymentUpload.Date.HasValue)
                    {
                        date = repaymentUpload.Date.Value.ToString("MM/dd/yyyy"); // apply approved date format
                    }
                    
                    // get validation results
                    string validationResults;
                    var flagsForThisRepayment = uploadFlagsWithDescriptions.Where(x => x.RepaymentUploadID == repaymentUpload.RepaymentUploadID);
                    if (flagsForThisRepayment.Count() > 0)
                    {
                        var failureFlag = flagsForThisRepayment.Where(x => x.SeverityDescription == "Failure").FirstOrDefault();
                        if (failureFlag != null)
                        {
                            validationResults = "<span class='glyphicon glyphicon-remove text-danger'></span> " + failureFlag.FlagDescription +
                                " This record will not be processed.";
                        }
                        else
                        {
                            validationResults = "<span class='glyphicon glyphicon-flag text-warning'></span> ";
                            foreach (var warningFlag in flagsForThisRepayment.Where(x => x.SeverityDescription == "Warning").ToList())
                            {
                                validationResults += warningFlag.FlagDescription + " ";
                            }
                        }
                    }
                    else
                    {
                        validationResults = "<span class='glyphicon glyphicon-ok text-success'></span>";
                    }

                    // create upload record for display
                    displayUploads.Add(new DisplayUpload
                    {
                        CustomerID = repaymentUpload.CustomerID,
                        CustomerName = customerName,
                        SeasonID = repaymentUpload.SeasonID,
                        SeasonName = seasonName,
                        Date = date,
                        Amount = repaymentUpload.Amount,
                        ValidationResults = validationResults
                    });
                }
            }
            return View(displayUploads);
        }
        // Process an uploaded repayment file
        public ActionResult ProcessRepaymentUpload(int uploadTransferID)
        {
            string msg;
            try
            {
                ProcessRepayments(uploadTransferID);
            }
            catch
            {
                // Add code to log error to logging system with details from exception as appropriate
                msg = "There was an error processing the file";
            }
            msg = "The uploaded file was processed successfully.";
            return RedirectToAction("UploadRepayments", "Home", new { msg = msg });
        }
        // Process repayments for a specific upload
        public void ProcessRepayments(int uploadTransferID)
        {
            // run stored procedure, passing in uploadTransferID
            using (OAFProjectDBContext context = new OAFProjectDBContext())
            {
                context.spProcessRepaymentUpload(uploadTransferID);
            }
        }
        // add validation information for upload records.
        // if the validation error is serious enough to cancel the record then 
        // set IsProcessed to true and skip to the next record.
        private void validateUploads(int uploadTransferID)
        {
            using (OAFProjectDBContext context = new OAFProjectDBContext())
            {
                List<UploadFlag> uploadFlags = new List<UploadFlag>();
                uploadFlags = context.UploadFlags.ToList();
                List<CustomerSummary> customerSummaries = new List<CustomerSummary>();
                customerSummaries = context.CustomerSummaries.ToList();
                foreach (RepaymentUpload repayment in context.RepaymentUploads.Where(x => x.UploadTransferID==uploadTransferID))
                {
                    // check for null customer ID
                    if (repayment.CustomerID == null)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Customer ID not found.").Select(x => x.UploadFlagID).First()
                        });
                        repayment.IsProcessed = true;
                        continue;
                    }
                    // check for invalid customer ID
                    if (context.Customers.Where(x => x.CustomerID==repayment.CustomerID).Count() == 0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "No customer matches this Customer ID.").Select(x => x.UploadFlagID).First()
                        });
                        repayment.IsProcessed = true;
                        continue;
                    }
                    // check for invalid season ID
                    if (repayment.SeasonID != null && context.Seasons.Where(x => x.SeasonID == repayment.SeasonID).Count() == 0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "No season matches this Season ID.").Select(x => x.UploadFlagID).First()
                        });
                        repayment.IsProcessed = true;
                        continue;
                    }
                    // check for amount paid equal to 0
                    if (repayment.Amount == 0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Amount paid is zero.").Select(x => x.UploadFlagID).First()
                        });
                        repayment.IsProcessed = true;
                        continue;
                    }
                    // check for customer not being enrolled in any seasons
                    if (customerSummaries.Where(x => x.CustomerID == repayment.CustomerID).Count()==0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Customer is not enrolled for any seasons.").Select(x => x.UploadFlagID).First()
                        });
                        repayment.IsProcessed = true;
                        continue;
                    }
                    // check for date not found
                    if (!repayment.Date.HasValue)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Date not found.").Select(x => x.UploadFlagID).First()
                        });
                    }
                    // check for date in the future
                    if (repayment.Date.HasValue && (DateTime.Now < repayment.Date.Value))
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Date is in the future.").Select(x => x.UploadFlagID).First()
                        });
                    }
                    // check for date over a year old
                    if (repayment.Date.HasValue && (DateTime.Now - repayment.Date.Value).TotalDays > 365)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Date is more than a year in the past.").Select(x => x.UploadFlagID).First()
                        });
                    }
                    // check for negative payment
                    if (repayment.Amount < 0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Amount paid is negative.").Select(x => x.UploadFlagID).First()
                        });
                    }
                    // check for customer already paying for specified season
                    if (repayment.SeasonID != null && 
                        customerSummaries.Where(x => x.CustomerID==repayment.CustomerID && 
                            x.SeasonID==repayment.SeasonID && 
                            x.TotalRepaid == x.Credit).Count() > 0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Customer had already paid for the specified season.").Select(x => x.UploadFlagID).First()
                        });
                    }
                    // check for customer already being caught up on payments
                    if (customerSummaries.Where(x => x.CustomerID == repayment.CustomerID && (x.TotalRepaid < x.Credit)).Count() == 0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Customer had already paid for all seasons.").Select(x => x.UploadFlagID).First()
                        });
                    }
                    // check for duplicate payment
                    if (context.RepaymentUploads.Where(x => x.RepaymentUploadID != repayment.RepaymentUploadID && 
                        x.CustomerID==repayment.CustomerID &&
                        x.SeasonID==repayment.SeasonID &&
                        x.Amount==repayment.Amount &&
                        x.UploadTransferID==repayment.UploadTransferID).Count() > 0)
                    {
                        context.RepaymentUploadFlagJunctions.Add(new RepaymentUploadFlagJunction
                        {
                            RepaymentUploadID = repayment.RepaymentUploadID,
                            UploadFlagID = uploadFlags.Where(x => x.Description == "Duplicate payment.").Select(x => x.UploadFlagID).First()
                        });
                    }
                }
                context.SaveChanges();
            }
        }
    }
}