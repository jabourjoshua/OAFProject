﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OAFProject.Models
{
    public class DisplaySummary
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public int SeasonID { get; set; }
        public string SeasonName { get; set; }
        public double Credit { get; set; }
        public double TotalRepaid { get; set; }
        public bool IsPaymentRequired { get; set; }
    }
}