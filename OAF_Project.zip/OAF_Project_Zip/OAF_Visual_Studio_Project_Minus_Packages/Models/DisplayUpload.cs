﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OAFProject.Models
{
    public class DisplayUpload
    {
        public Nullable<int> CustomerID { get; set; }
        public string CustomerName { get; set; }
        public Nullable<int> SeasonID { get; set; }
        public string SeasonName { get; set; }
        public string Date { get; set; }
        public Nullable<double> Amount { get; set; }
        public string ValidationResults { get; set; }
    }
}