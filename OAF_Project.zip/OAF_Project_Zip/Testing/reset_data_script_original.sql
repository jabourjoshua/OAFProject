use OAFProject
go
delete from repayments;
delete from repaymentuploads;
delete from repaymentuploadtransfers;
delete from customersummaries;
delete from customers;
delete from seasons;
delete from repaymentuploadflagjunction;
delete from uploadflags;
delete from uploadflagseverities;

-- all inserts for seasons, customers, and customersummaries below.
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(110,'2012, Short Rain','8/1/2012',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(120,'2013, Long Rain','3/1/2013',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(130,'2013, Short Rain','8/1/2013',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(140,'2014, Long Rain','3/1/2014',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(150,'2014, Short Rain','8/1/2014',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(160,'2015, Long Rain','3/1/2015',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(170,'2015, Short Rain','8/1/2015',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(180,'2016, Long Rain','3/1/2016',null);
INSERT INTO [dbo].[Seasons]([SeasonID],[SeasonName],[StartDate],[EndDate])VALUES(190,'2016, Short Rain','8/1/2016',null);


insert into dbo.customers(CustomerID,CustomerName) VALUES(1,'Fred Barasa');
insert into dbo.customers(CustomerID,CustomerName) VALUES(2,'Imelda Kundu');
insert into dbo.customers(CustomerID,CustomerName) VALUES(3,'Leah Kundu');
insert into dbo.customers(CustomerID,CustomerName) VALUES(4,'Beatrice Wafula Machuma');
insert into dbo.customers(CustomerID,CustomerName) VALUES(5,'John Juma Shitoshe');
insert into dbo.customers(CustomerID,CustomerName) VALUES(7,'Donald Masika');
insert into dbo.customers(CustomerID,CustomerName) VALUES(8,'Bilasio Masinde');
insert into dbo.customers(CustomerID,CustomerName) VALUES(9,'Peter Masinde');
insert into dbo.customers(CustomerID,CustomerName) VALUES(10,'Francis S. Misiko');
insert into dbo.customers(CustomerID,CustomerName) VALUES(11,'Peter Wechuli Nakitare');
insert into dbo.customers(CustomerID,CustomerName) VALUES(12,'Mwanaisha Nekesa');
insert into dbo.customers(CustomerID,CustomerName) VALUES(13,'John Nyongesa');

INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,110,7900,7900);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,110,7900,7900);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,110,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,110,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,120,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,120,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,120,7050,7050);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,120,7050,7000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,120,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,120,5250,5250);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,120,6950,6950);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,120,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,120,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,120,5250,5250);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,120,5250,5250);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,130,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,130,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,130,0,0);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,130,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,130,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,130,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,130,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,130,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,130,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,130,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,130,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,140,4500,4000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,140,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,140,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,140,7900,7900);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,140,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,140,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,140,7900,7900);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,140,7900,7900);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,140,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,140,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,140,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,150,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,150,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,150,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,150,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,150,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,150,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,150,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,150,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,150,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,150,6200,6000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,150,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,160,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,160,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,160,4500,4000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,160,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,160,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,160,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,160,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,160,6200,7200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,160,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,160,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,160,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,170,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,170,6200,6000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,170,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,170,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,170,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,170,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,170,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,170,4500,4000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,170,4500,4500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,170,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,170,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(1,180,6200,600);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(2,180,6200,3000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(3,180,6200,900);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(4,180,6200,4000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(5,180,6200,400);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(7,180,6200,620);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(8,180,6200,6200);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(9,180,4500,500);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(10,180,4500,450);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(11,180,4500,5000);
INSERT INTO [dbo].[CustomerSummaries]([CustomerID],[SeasonID],[Credit],[TotalRepaid])VALUES(12,180,4500,450);

insert into dbo.uploadflagseverities(Description) VALUES('Success');
insert into dbo.uploadflagseverities(Description) VALUES('Warning');
insert into dbo.uploadflagseverities(Description) VALUES('Failure');

insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Failure'),'Customer ID not found.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Failure'),'No customer matches this Customer ID.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Failure'),'No season matches this Season ID.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Failure'),'Amount paid is zero.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Failure'),'Customer is not enrolled for any seasons.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Warning'),'Date not found.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Warning'),'Date is in the future.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Warning'),'Date is more than a year in the past.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Warning'),'Customer had already paid for all seasons.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Warning'),'Amount paid is negative.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Warning'),'Customer had already paid for the specified season.');
insert into dbo.uploadflags(FlagSeverityID,Description) VALUES((select FlagSeverityID from dbo.UploadFlagSeverities where Description=
    'Warning'),'Duplicate payment.');